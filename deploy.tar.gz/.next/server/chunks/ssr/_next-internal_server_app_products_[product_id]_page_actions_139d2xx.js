module.exports=[7480,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_products_%5Bproduct_id%5D_page_actions_139d2xx.js.map