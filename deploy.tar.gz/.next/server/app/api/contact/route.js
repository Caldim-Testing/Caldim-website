var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/contact/route.js")
R.c("server/chunks/[externals]__1ae-aam._.js")
R.c("server/chunks/[root-of-the-server]__1o7mzru._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_contact_route_actions_03lj3y1.js")
R.m(10044)
module.exports=R.m(10044).exports
