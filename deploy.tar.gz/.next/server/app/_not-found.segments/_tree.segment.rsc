:HL["/_next/static/chunks/2i81259ikzvkg.css","style"]
:HL["/_next/static/chunks/1w3_xh7kw_-9l.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"tSPuV3BRQUCkUg81mlMGk"}
