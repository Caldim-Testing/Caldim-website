globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/tSPuV3BRQUCkUg81mlMGk/_buildManifest.js",
    "static/tSPuV3BRQUCkUg81mlMGk/_ssgManifest.js",
    "static/tSPuV3BRQUCkUg81mlMGk/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0o5eyasa-fdkl.js",
    "static/chunks/07-hzktxqjvzd.js",
    "static/chunks/11oof8oxnxiv9.js",
    "static/chunks/1eglloh0s_w8l.js",
    "static/chunks/turbopack-1jsyzbfis31c_.js"
  ]
};
